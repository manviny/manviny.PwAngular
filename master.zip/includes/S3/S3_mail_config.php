<?php 

	$smtpHost       = "email-smtp.eu-west-1.amazonaws.com";
	$smtpUsername   = "AKIAIF7FBYY3ZLT2KIEA";
	$smtpPassword   = "AkWdF49iS9ztPjFFPLPCgo6ht6sglBm0eTP+UDWSUuiN";

	$from 			= "info@patrimonio24.com";
	$from_name 		= "Patrimonio 24";

 
?>